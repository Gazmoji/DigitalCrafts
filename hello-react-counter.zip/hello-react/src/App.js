import { Component } from "react";
import Counter from "./components/Counter";

class App extends Component {
  render() {

    return (
      <>
        <h1>App</h1>
        <Counter />

      </>
    )
  }
}

export default App 






