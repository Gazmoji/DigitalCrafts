const express = require('express')
const app = express()
const mustacheExpress = require('mustache-express')
const models = require('./models')

app.use(express.urlencoded())

// setting up Express to use Mustache Express as template pages 
app.engine('mustache', mustacheExpress())
    // the pages are located in views directory
app.set('views', './views')
    // extension will be .mustache
app.set('view engine', 'mustache')

app.get('/', async (req, res) => {
    const movies = await models.Movie.findAll({})
    console.log(movies)
    res.render('index', {movies: movies})
})

app.listen(8080,() => {
    console.log('Server is running...')
})


