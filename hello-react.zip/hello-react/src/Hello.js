import { Component } from "react";


class Hello extends Component {
    render() {
        return (
            <>
                <h1>Hello, {this.props.name}</h1>
                <p>{this.props.age}</p>
            </>
        )
    }
}

export default Hello