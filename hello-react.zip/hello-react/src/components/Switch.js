import { Component } from "react";

class Switch extends Component {

    constructor() {
        super() 
        this.state = {
            isOn: false 
        }
    }

    handleClick = () => {
        console.log('handleClick')
        this.setState({
            isOn: !this.state.isOn 
        })
    }

    render() {
        return (
            <button onClick = {this.handleClick}>{this.state.isOn ? "OFF": "ON"}</button>
        )
    }
}

export default Switch 