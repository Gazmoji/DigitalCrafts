import { Component } from "react";

class Counter extends Component {

    constructor() {
        // constructor of the parent class (Component)
        super() 
        // custom property 
        //this.value = 99

        // STATE 
        // state is private 
        // state is for a particular component and cannot be used outside of that component 
        this.state = {
            counterValue: 99, 
            isAuthenticated: false 
        }
    }

    handleIncrement = () => {
        //this.value += 1 
        //console.log(this.value)

         // WRONG WRONG WRONG WRONG WRONG 
       // this.state.counterValue += 1 
         // WRONG WRONG WRONG WRONG WRONG 

        // STATE CANNOT BE CHANGED, STATE CAN ONLY BE REPLACED
        // When setState is called, it AUTOMATICALLY calls the render function
        // setState updates the state asynchronously 
        /*
        this.setState({
            counterValue: this.state.counterValue + 1 
        }) */

        this.setState({
            counterValue: this.state.counterValue + 1
        }, () => {
            // this fires when the state is updated 
            // this display the updated value 
            console.log(this.state.counterValue)
        })

        // this displays the old value 
        //console.log(this.state.counterValue)

        console.log('handleIncrement')
    }

    /*
    handleIncrement() {
       
    } */

    render() {
       
        return (
            <>
            <h1>{this.state.counterValue}</h1>
            <button onClick = {this.handleIncrement}>Increment</button>
            </>
        )
    }
}

export default Counter 