import { Component } from "react";
import Counter from "./components/Counter";
import Switch from "./components/Switch";
import MovieList from "./components/MovieList";

class App extends Component {

  constructor() {
    super() 
    this.state = {
      movies: [], 
      searchTerm: '' 
    }
  }

   // fired when the component is mounted on the virtual dom 
  componentDidMount() {
    fetch('https://www.omdbapi.com/?s=Batman&page=2&apiKey=564727fa')
    .then(response => response.json())
    .then(result => {
      this.setState({
        movies: result.Search 
      })
    })
  }

  handleSearchTextBoxChange = (e) => {
    console.log(e.target.value)
    this.setState({
      searchTerm: e.target.value 
    })
  }

  handleSearchClick = () => {

    // moviesUrl 
    const moviesUrl = `https://www.omdbapi.com/?s=${this.state.searchTerm}&page=2&apiKey=564727fa`
    fetch(moviesUrl)
    .then(response => response.json())
    .then(result => {
      this.setState({
        movies: result.Search 
      })
    })
  }

  render() {

    /* THIS WILL CAUSE INFINITE LOOP 
    this.setState({
      counter: this.state.counter + 1 
    }) */

    return (
      <>
        <h1>App</h1>
        <Counter />

        <Switch />
        <input type = 'text' placeholder="Search movie..." onChange = {this.handleSearchTextBoxChange} />
        <button onClick = {this.handleSearchClick}>Search</button>
        <MovieList movies = {this.state.movies} />
      </>
    )
  }
}

export default App 






