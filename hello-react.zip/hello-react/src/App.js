import { Component } from "react";
import Header from "./Header";
import Hello from "./Hello";
import TaskList from "./TaskList";

// npx create-react-app hello-react

class App extends Component {
  render() {

    const tasks = [
      {name: 'Mow the lawn', priority: 'high'}, 
      {name: 'Wash car', priority: 'low'}, 
    ]

    return (
      <>
        <TaskList tasks = {tasks} />
      </>
    )
  }
}

export default App 






